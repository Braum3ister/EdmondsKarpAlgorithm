package edu.kit.stephan.escaperoutes.commands;

import edu.kit.stephan.escaperoutes.errors.Errors;
import edu.kit.stephan.escaperoutes.errors.SemanticsException;
import edu.kit.stephan.escaperoutes.graphs.Edge;
import edu.kit.stephan.escaperoutes.graphs.EscapeNetwork;
import edu.kit.stephan.escaperoutes.graphs.EscapeNetworksDatabase;
import edu.kit.stephan.escaperoutes.graphs.Vertex;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Command {
    /**
     * Executes the Add-Network Command
     */
    ADD_NETWORK(CommandParser.ADD_NETWORK) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            String resultMessage;

            try {
                resultMessage = escapeNetworksDatabase.addNewEscapeNetwork(Command.createEscapeNetwork(parameters));
            } catch (SemanticsException e) {
                return new Result(Result.ResultType.FAILURE, e.getMessage());
            }
            return new Result(Result.ResultType.SUCCESS, resultMessage);
        }

    },
    /**
     * Executes the Add Section Command
     */
    ADD_SECTION(CommandParser.ADD_SECTION) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            String resultMessage;

            try {
                resultMessage = escapeNetworksDatabase.addNewSection(parameters.get(INDEX_OF_NAME),
                        Command.createEdgesOutOfInput(parameters.get(INDEX_OF_PARAMETERS)));
            } catch (SemanticsException e) {
                return new Result(Result.ResultType.FAILURE, e.getMessage());
            }
            return new Result(Result.ResultType.SUCCESS, resultMessage);
        }
    },

    /**
     * Executes the list Command which shows all networks
     */
    LIST_ALL_NETWORKS(CommandParser.LIST_ONE) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            return new Result(Result.ResultType.SUCCESS, escapeNetworksDatabase.listNetworks());
        }
    },

    /**
     * Executes the list Command which shows the calculated flows of a specific network
     */
    LIST_SPECIFIC_NETWORK(CommandParser.LIST_TWO) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            String resultMessage;

            try {
                resultMessage = escapeNetworksDatabase.listFlowOfSpecificNetwork(parameters.get(INDEX_OF_NAME));
            } catch (SemanticsException e) {
                return new Result(Result.ResultType.FAILURE, e.getMessage());
            }
            return new Result(Result.ResultType.SUCCESS, resultMessage);
        }
    },

    /**
     * Executes the flow Command, which calculates the flow between two given Points
     */
    FLOW(CommandParser.FLOW) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            String resultMessage;

            try {
                resultMessage = escapeNetworksDatabase.calculateOrGetFlow(parameters.get(INDEX_OF_NAME)
                        , new Vertex(parameters.get(INDEX_OF_FLOW_START_POINT))
                        , new Vertex(parameters.get(INDEX_OF_FLOW_END_POINT)));
            } catch (SemanticsException e) {
                return new Result(Result.ResultType.FAILURE, e.getMessage());
            }
            return new Result(Result.ResultType.SUCCESS, resultMessage);
        }
    },

    /**
     * Executes the print Command, which prints a Network which corresponds to a given identifier
     */
    PRINT(CommandParser.PRINT) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            String resultMessage;

            try {
                resultMessage = escapeNetworksDatabase.printEscapeNetwork(parameters.get(INDEX_OF_NAME));
            } catch (SemanticsException e) {
                return new Result(Result.ResultType.FAILURE, e.getMessage());
            }
            return new Result(Result.ResultType.SUCCESS, resultMessage);
        }
    },

    /**
     * Executes the Quit Command
     */
    QUIT(CommandParser.QUIT) {
        @Override
        public Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase) {
            return new Result(Result.ResultType.SUCCESS);
        }
    };

    private static final int INDEX_OF_FLOW_START_POINT = 2;
    private static final int INDEX_OF_FLOW_END_POINT = 3;
    private static final int INDEX_OF_PARAMETERS = 2;
    private static final int INDEX_OF_NAME = 1;
    private final String commandName;
    Command(String commandName) {
        this.commandName = commandName;
    }

    public abstract Result executeCommand(List<String> parameters, EscapeNetworksDatabase escapeNetworksDatabase);

    public String getCommandName() {
        return commandName;
    }

    public static Command getCommand(String commandName) {
        return Arrays.stream(Command.values())
                .filter(command -> command.getCommandName().equals(commandName))
                .findFirst().orElse(null);
    }

    /**
     *
     * Method which creates Edges
     * @param parameterEdges Edges represented as String
     * @return the parsed Edge
     * @throws SemanticsException throws an Error if Edge is not valid
     */
    private static Edge createEdgesOutOfInput(String parameterEdges) throws SemanticsException {
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(parameterEdges);
        //noinspection ResultOfMethodCallIgnored
        matcher.find();
        String nameOfFirstVertex = parameterEdges.substring(0, matcher.start());
        String nameOfSecondVertex = parameterEdges.substring(matcher.end());
        if (nameOfFirstVertex.equals(nameOfSecondVertex)) throw new SemanticsException(Errors.LOOPS_NOT_ALLOWED);
        int capacity;
        try {
            capacity = Integer.parseInt(matcher.group());
        } catch (NumberFormatException e) {
            throw new SemanticsException(Errors.CAPACITY_IS_NOT_A_INT);
        }
        return new Edge(new Vertex(nameOfFirstVertex), new Vertex(nameOfSecondVertex), capacity);
    }

    /**
     * Method which creates an EscapeNetwork
     * @param parameters the parameters needed to create an Escape Network
     * @return the finished EscapeNetwork
     * @throws SemanticsException if the semantics are wrong, which are needed to construct the EscapeNetwork
     */
    private static EscapeNetwork createEscapeNetwork(List<String> parameters) throws SemanticsException {
        String[] edgesString = parameters.get(INDEX_OF_PARAMETERS).split(";");
        List<Edge> edges = new LinkedList<>();

        for (String s : edgesString) {
            Edge edge = createEdgesOutOfInput(s);
            if (edges.contains(edge)) {
                throw new SemanticsException(Errors.CANT_ADD_EDGE_WHICH_EXIST);
            }
            edges.add(edge);
        }
        return new EscapeNetwork(parameters.get(INDEX_OF_NAME), edges);
    }


}
